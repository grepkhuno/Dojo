function changeInnerTextTo(element){
    if(element.innerText=="Logout"){
           element.innerText="Login" ;
    }else{
        element.innerText="Logout" ;
    }}
    var counterVal = 0;
    function likeCounter(element){
      var counter=  element.innerText=++counterVal;
       var numText = document.querySelector("#numOfLikes")
       numText.innerHTML=counter;
    }
function removeBtn (element){
    element.remove();
}
function modifyCounterText(){
    var numText = document.querySelector("#numOfLikes")


}